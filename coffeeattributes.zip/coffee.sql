-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2020 at 07:08 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpmyadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `coffee`
--

CREATE TABLE `coffee` (
  `ID` int(11) NOT NULL,
  `CoffeeType` varchar(255) COLLATE utf8_bin NOT NULL,
  `Size` varchar(255) COLLATE utf8_bin NOT NULL,
  `AvgPrice` double NOT NULL,
  `Store` varchar(255) COLLATE utf8_bin NOT NULL,
  `Sugar` varchar(100) COLLATE utf8_bin NOT NULL,
  `Calories` varchar(100) COLLATE utf8_bin NOT NULL,
  `Total_Fat` varchar(100) COLLATE utf8_bin NOT NULL,
  `Protein` varchar(100) COLLATE utf8_bin NOT NULL,
  `Caffeine` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `coffee`
--

INSERT INTO `coffee` (`ID`, `CoffeeType`, `Size`, `AvgPrice`, `Store`, `Sugar`, `Calories`, `Total_Fat`, `Protein`, `Caffeine`) VALUES
(1, 'Caffe Latte ', 'Small', 2.95, 'Starbucks', '100', '3.5', '9', '6', '75'),
(2, 'Caffe Latte ', 'Medium', 3.65, 'Starbucks', '150', '6', '14', '10', '75'),
(3, 'Caffe Latte ', 'Large', 4.15, 'Starbucks', '190', '7', '18', '13', '150'),
(4, 'Caffe Mocha ', 'Small', 3.45, 'Starbucks', '200', '9', '18', '7', '90'),
(5, 'Caffe Mocha ', 'Medium', 4.15, 'Starbucks', '290', '13', '28', '11', '95'),
(6, 'Caffe Mocha ', 'Large', 4.65, 'Starbucks', '360', '15', '35', '13', '175'),
(7, 'White Chocolate Mocha ', 'Small', 3.75, 'Starbucks', '230', '10', '27', '7', '75'),
(8, 'White Chocolate Mocha ', 'Medium', 4.45, 'Starbucks', '340', '14', '41', '11', '75'),
(9, 'White Chocolate Mocha ', 'Large', 4.75, 'Starbucks', '430', '18', '53', '14', '150'),
(10, 'Freshly Brewed Coffee ', 'Small', 1.85, 'Starbucks', '5', '0', '0', '0', '180'),
(11, 'Freshly Brewed Coffee ', 'Medium', 2.1, 'Starbucks', '5', '0', '0', '0', '270'),
(12, 'Freshly Brewed Coffee ', 'Large', 2.45, 'Starbucks', '5', '0', '0', '1', '360'),
(13, 'Cinnamon Dolce Latte ', 'Small', 3.65, 'Starbucks', '190', '8', '21', '6', '75'),
(14, 'Cinnamon Dolce Latte ', 'Medium', 4.25, 'Starbucks', '270', '11', '32', '9', '75'),
(15, 'Cinnamon Dolce Latte ', 'Large', 4.65, 'Starbucks', '340', '13', '41', '12', '150'),
(16, 'Caramel Macchiato ', 'Small', 3.75, 'Starbucks', '120', '4', '15', '5', '75'),
(17, 'Caramel Macchiato ', 'Medium', 4.15, 'Starbucks', '190', '6', '25', '8', '75'),
(18, 'Caramel Macchiato ', 'Large', 4.65, 'Starbucks', '250', '7', '33', '10', '150'),
(19, 'Caramel Flan Latte ', 'Small', 3.75, 'Starbucks', '240', '8', '24', '7', '75'),
(20, 'Caramel Flan Latte ', 'Medium', 4.55, 'Starbucks', '350', '11', '36', '10', '75'),
(21, 'Caramel Flan Latte ', 'Large', 4.75, 'Starbucks', '450', '13', '47', '13', '150');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coffee`
--
ALTER TABLE `coffee`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coffee`
--
ALTER TABLE `coffee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
