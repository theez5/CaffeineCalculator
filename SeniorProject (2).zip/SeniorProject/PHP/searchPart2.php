<?php 

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	if($con) {
			
			session_start();
      $quantity = mysqli_real_escape_string($con,$_COOKIE['words']);
      echo $quantity;
		}