<?php 
	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	if($con) {
		$quantity = mysqli_real_escape_string($con,$_POST['quantity']);
		$words = mysqli_real_escape_string($con,$_POST['words']);
		
		session_start();
		setcookie("cookie", $quantity, time() + (86400 * 30), "/");
		setcookie("words", $words, time() + (86400 * 30), "/");

		if($_COOKIE["words"]!=NULL && $_COOKIE["words"]!=' ') {
			header("Location: searchPart3.php");
		} else {
			header("Location: ../Calculator.html");
		}
		
	}

 ?>