<?php 	

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();
	$user = $_SESSION['user'];
	$query = "SELECT * FROM phpmyadmin.userLogin WHERE Username='$user'";
	$connect = mysqli_query($con,$query);

	if(isset($_SESSION['user'])) {
		while ($row=mysqli_fetch_array($connect)) {
           	$id = $row["id"];
           	$user = $row["Username"];
           	//$_SESSION['user'] = $user;
           	$pass = $row["Password"];
           	$email = $row["Email"];
           	$Budget = $row["Budget"];
           	$_SESSION['budget'] = $Budget;

           		}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>


	<meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../CSS/Welcome.css">
	<style type="text/css">
		input[type="number"] {

		}
 	</style>
</head>
<body>
<div class="container">
			<header class="active" id="navbar">
				<a  href="#" class="logo">Caffiene<span>Calculator</span></a>
					

				<ul>
					<li><a href="#" class="active">Home</a></li>
					<li><a href="signout.php" class="logout">Sign Out</a></li>
					<li><a href="settings.php"><?php echo $_SESSION['user']; ?></a></li>
					<li><a href="Calculator.html"> Budget: <?php echo "$$Budget"; } else { 

							session_unset();     // unset $_SESSION variable for the run-time 
    						session_destroy(); 


						header("Location: ../index.html");
					}?></a></li>
					<li><a href="portfolio.php">Need Help?</a></li>
					
				</ul>	
				<span class="menuIcon" onclick="menuToggle();"></span>
				</header>	
				<h1>Edit/View Budget Below:</h1>
				<h1>(Can be a Daily,Weekly,Monthly,Yearly Budget)</h1>
				<form action="updateBudget.php" method ="POST">
				<input type="number" name="budget" value=<?php 	echo "$Budget"; ?>><br><br>
				<input type="submit" name="">
				<input type="reset" name="">
			</form>
			

</div>
</body>
</html>