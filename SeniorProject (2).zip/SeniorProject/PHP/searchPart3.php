<?php 

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	if($con) {
    echo " <div class='container'>
      <header class='active' id='navbar'>
        <a  href='#' class='logo'>Coffee<span>Shop</span></a>
        <ul>
          <li><a href='../index.html'>Home</a></li>
          <li><a href='#'>Menu</a></li>
          <li><a href='Calculator.html' class='active'>Calculator</a></li>
          <li><a href='#'>About</a></li>
          <li><a href='#'>Contact</a></li>
        </ul> 
        <span class='menuIcon' onclick='menuToggle();'></span>
        </header> 
        <label class='cups'>You're So Close! Just Click On Any Coffee(s) And Continue.</label>
";
			
		session_start();
    $words = $_COOKIE['words'];
		$query2 = mysqli_real_escape_string($con,$words);
		$query = ucwords($query2);
		
		$sql = "SELECT * FROM phpmyadmin.coffee WHERE CoffeeType LIKE '%$query%' or Store LIKE '%$query%' order by AvgPrice Asc";
		$connect = mysqli_query($con,$sql);
		$rows = mysqli_num_rows($connect);

		if($rows>0) {
			
				
                                    $i=0;
			 while($row = mysqli_fetch_array($connect))  {
			 	$ID = $row['ID'];
			 	$CoffeeType = $row['CoffeeType'];
			 	$Size = $row['Size'];
			 	$AvgPrice = $row['AvgPrice'];
			 	$Store = $row['Store'];
        if($ID <>"")
        echo "
        
        <div class='contain'>
  <form method='POST' action='Calculate.php'>
    <div class='pricing-table'>
      <h3 class='heading' name='Type[$i]' value='$ID'>$CoffeeType</h3>
      <h3 class='heading'>$Size</h3>
      <h1 class='service-price'>
        $AvgPrice
        <sup class='dollar-sign'>$</sup>
      </h1>
      <label class='con'>&nbsp
      <input type='checkbox' name='check[$i]' value='$ID'>
      <span class='checkmark'></span>
      </label>
      <ul class='features-list'>
        <li>
          Location: $Store
        </li>
      
      </ul>
      
    <input type='submit' class='order-button' name='submit' value='Next Step'>

   
    </div>
    </div>";

			 		
			 		 $i++;
                                                
		} 
    echo "</form>
    </div>";
  }
		else {
			echo "<h1 class='center'>Try Searching Again..Click <a href='../index.html'> Here</h1>";
		}
	


}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
   <title></title>
      <link rel="stylesheet" type="text/css" href="../CSS/index.css">
      <link rel="stylesheet" type="text/css" href="../CSS/check.css">
   <style type="text/css">
     *{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body{
      font-family: tahoma;
    }
   label {
  font-size: 34px;
  font-weight: 700;
  color: #333;
}
  
    .contain{
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 10%;
     
      
    }
    
    .contain .pricing-table{
      display: block;
      padding: 20px;
      background: #ccc;
      overflow: hidden;
      width: 300px;
      margin: 10px;
      border-radius: 3px;
      box-shadow: 0px 8px 15px rgba(0,0,0,0.2);
      transform: scale(1);
      transition: all 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    
    .contain .pricing-table:nth-child(1){
      background-image: linear-gradient(135deg, #592d1d 10%, #c89253 100%);
    }
    
    
    
    
    .contain .pricing-table:hover{
      transform: scale(1.2);
      z-index: 100;
    }
    
    .pricing-table .icon{
      display: block;
      width: 70px;
      height: 70px;
      background: white;
      text-align: center;
      line-height: 70px;
      font-size: 2.2em;
      margin: 20px auto;
      border-radius: 50px;
      box-shadow: 0px 5px 5px rgba(0,0,0,0.2);
      
    }
    
    .pricing-table .icon span{
      transform: scale(1);
      transition: all 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    
    
    .pricing-table .type-01{
      color: #fccf31;
      
    }
    
    
    .pricing-table .type-02{
      color: #f761a1;
      
    }
    
    .pricing-table .type-03{
      color: #43cbff;
      
    }
    
    .heading{
      color: white;
      text-align: center;
      text-transform: capitalize;
      font-weight: lighter;
      padding: 10px;
      font-size: 1.2em;
    }
    
    .service-price{
      color: white;
      text-align: center;
      font-size: 3em;   
      
    }
    
    .service-price .dollar-sign{
      font-size: 0.6em;
      margin-left: -10px;
      
    }
    
    .features-list{
      list-style: none;
      display: block;
      margin: 20px auto;
      width: 80%;
      
    }
    
    .features-list li{
      color: white;
      text-align: center;
      display: block;
      text-transform: capitalize;
      font-weight: lighter;
      font-size: 0.9em;
      height: 30px;
      line-height: 30px;
    }
    
    .order-button{
      border: none;
      display: block;
      width: 70%;
      height: 40px;
      margin: 5px auto;
      border-radius: 50px;
      box-shadow: 0px 8px 15px rgba(0,0,0,0.2);
      font-family: tahoma;
      text-transform: capitalize;
      color: rgba(0,0,0,0.5);
      background: white;
      cursor: pointer;
      
    }
    
    
    .order-button:focus{
      outline: none;
    }
   </style>

 </head>
 <body>

 </body>
 </html>