<?php 	

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	if($con) {
		session_start();
		$username = mysqli_real_escape_string($con,$_POST['login']);
		$password = mysqli_real_escape_string($con,$_POST['pass']);

		$sql = "SELECT * FROM phpmyadmin.userlogin WHERE Username='$username' and Password='$password'";
		$connect = mysqli_query($con,$sql);
		$count = mysqli_num_rows($connect);
		if($connect) {
			if($count>0 ) {
				echo "Success";
					
					$_SESSION['user'] = $username;
					header("Location: Welcome.php");
					exit();
           		

		} else {
			echo "Not a Registered User";
			}
		}
	}


 ?>