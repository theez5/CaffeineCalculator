<?php 

	if($_POST['submit']) {
		foreach ($_POST["numo"] as $i)  {
				$query = "SELECT * FROM phpmyadmin.coffee WHERE (ID = $i)";
				echo $query;
		}
	}
 ?>