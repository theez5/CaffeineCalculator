<?php 	

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	if($con) {
		if(isset($_POST['submit'])) {
			$user = mysqli_real_escape_string($con,$_POST['user']);
			$pass = mysqli_real_escape_string($con,$_POST['pass']);
			$email = mysqli_real_escape_string($con,$_POST['email']);
			$budget = mysqli_real_escape_string($con,$_POST['budget']);

	$sql = "INSERT INTO phpmyadmin.userLogin(Username,Password,Email, Budget) VALUES ('$user','$pass','$email', $budget)";
			$insert = mysqli_query($con,$sql);
			
			$newTable = "CREATE TABLE phpmyadmin.Portfolio_$user (
id int NOT NULL auto_increment,
Calories double NOT NULL,
Fat double NOT NULL,
Caffeine double NOT NULL,
Protein double NOT NULL,
Sugar double NOT NULL,
Quantity int NOT NULL,
Primary Key(id)
)";
			$insertTable = mysqli_query($con,$newTable);
			
		

			$sql2 = "INSERT INTO phpmyadmin.Portfolio_$user(Calories,Fat,Caffeine, Protein, Sugar, Quantity) VALUES (0,0,0,0,0,0)";
			$insert2 = mysqli_query($con,$sql2);

			

				if($insert2) {
				echo "Success";
				header("Location: Welcome.php");
					session_start();
					$_SESSION['user'] = $user;
					exit();
			} else {
				echo "Error";
				echo "$sql";
			}
			echo $newTable;
		}
	}

	
	mysqli_close($con);
 ?>