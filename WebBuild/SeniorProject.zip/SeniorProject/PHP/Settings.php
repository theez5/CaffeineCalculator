<?php 	

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();
	$user = $_SESSION['user'];
	
	$query = "SELECT * FROM phpmyadmin.userLogin WHERE Username='$user'";
	$query2 = "SELECT * FROM phpmyadmin.portfolio_$user";
	$connect = mysqli_query($con,$query);
	$connect2 = mysqli_query($con,$query2);

	$query3 = "SELECT * FROM phpmyadmin.CoffeeAttributes";
	$connect3 = mysqli_query($con,$query3);

	$query4 = "SELECT * FROM phpmyadmin.CoffeeAttributes";
	$connect4 = mysqli_query($con,$query4);

	if(isset($user)) {
		while ($row=mysqli_fetch_array($connect)) {
           	$id = $row["id"];
           	$user = $row["Username"];
           	$pass = $row["Password"];
           	$email = $row["Email"];
           	$Budget = $row["Budget"];
           
           		}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>


	<meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../CSS/Welcome.css">
	<link rel="stylesheet" type="text/css" href="../CSS/Table.css">
</head>
<body>
<div class="container">
			<header class="active" id="navbar">
				<a  href="#" class="logo">My<span>Settings</span></a>
					

				<ul>
					<li><a href="Welcome.php">Home</a></li>
					<li><a href="signout.php" class="logout">Sign Out</a></li>
					<li><a href="settings.php" class="active"><?php echo $user; ?></a></li>
					<li><a href="Calculator.html"> Budget: <?php echo "$$Budget"; ?>
					</a></li>
					<li><a href="Doc5.pdf">Need Help?</a></li>
					
				</ul>	
				<span class="menuIcon" onclick="menuToggle();"></span>
				</header>	
			<form action="updateSettings.php" method='POST'>
			<table border="1" align="center" class="contained">
				<tr>
					<th>Product ID</th>
					<th>Calories</th>
					<th>Total Fat</th>
					<th>Caffeine (MG)</th>
					<th>Protein</th>
					<th>Sugar</th>
					<th>Type of Coffee</th>
					<th>Coffee Size</th>
					<th>Quantity</th>
				</tr>
				<?php 
				$i=0;
				while ($rows=mysqli_fetch_array($connect2)) {
					$product_id = $rows['id'];
					$Calories = $rows['Calories'];
					$Fat = $rows['Fat'];
					$Caffeine = $rows['Caffeine'];
					$Protein = $rows['Protein'];
					$Sugar = $rows['Sugar'];
					$Quantity = $rows['Quantity'];

					if($product_id <>"")

				 ?>
				<tr>
					<td align="center">
					<?php echo "
					<input type='hidden' name='product_id[$i]' value='$product_id'>$product_id"
					?>
					</td>
				
					<td align="center" >
					<?php 
					echo "<input type='number' name='Calories[$i]' value='$Calories'>";
					?><br>
					<p style="color: white;">Calories</p>
				</td>

					<td align="center">
					<?php 
					echo "<input type='number' name='Fat[$i]' value='$Fat'>";
					?><br>
					<p style="color: white;">Grams</p>
				</td>

					<td align="center">
					<?php 
					echo "<input type='number' name='Caffeine[$i]' value='$Caffeine'>";
					?><br>
					<p style="color: white;">Miligrams</p>
				</td>

					<td align="center">
					<?php 
					echo "<input type='number' name='Protein[$i]' value='$Protein'>";
					?><br>
					<p style="color: white;">Grams</p>
				</td>

					<td align="center">
					<?php 
					echo "<input type='number' name='Sugar[$i]' value='$Sugar'>";
					?><br>
					<p style="color: white;">Grams</p>
				</td>

					<td>
					<select name="Types">
			<?php 
				while($Attributes=mysqli_fetch_array($connect3)){
			 ?>

			 <option value="<?php echo $Attributes['Coffee_Type']; ?>"><?php echo $Attributes['Coffee_Type']; ?></option>
			 <?php } ?>
			 </select>
			 
				</td>

					<td>
					<select name="Sizes">
			<?php 
				while($Attributes2=mysqli_fetch_array($connect4)){
			 ?>

			 <option value="<?php echo $Attributes2['Coffee_Size']; ?>"><?php echo $Attributes2['Coffee_Size']; ?></option>
			 <?php } ?>
			 </select>
			 
				</td>

					<td align="center">
					<?php 
					echo "<input type='number' name='Quantity[$i]' value='$Quantity'>";
					?><br>
					<p style="color: white;">Cup(s)</p>
				</td>

					<?php 
						$i++;
					}
					 ?>
					 
				</tr>
				<tr>
				<td colspan="9"><input type="submit" value="Update Portfolio"></td>
			</tr>
			</table>

</form>
<?php 
	
	} else { 

							session_unset();     // unset $_SESSION variable for the run-time 
    						session_destroy(); 


						header("Location: ../index.html");
					}

 ?>
</div>
</body>
</html>