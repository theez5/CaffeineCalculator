<?php 


	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();

	$user = $_SESSION['user'];
	$Budget = $_SESSION['budget'];

	if($con) {
		if(isset($user)) {
			$sql = "SELECT * FROM phpmyadmin.Portfolio_$user";
			$connect = mysqli_query($con,$sql);
		
	} else {
		header("Location: ../index.html");
	}







}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<link rel="stylesheet" type="text/css" href="../CSS/Welcome.css">
 	<style type="text/css">
 		h2 {
 			text-align: center;
 			color: white;
 		}
 		a {
 			position: relative;
	text-decoration: none;

	padding: 4px 10px;
	color: #fff;
 		}
 		a:before {
	content: '';
	position: absolute;
	top: 0;
	left: 0;
	width: 0;
	height: 100%;
	border-bottom: 5px solid #dea059;

	box-shadow: 0 15px 20px rgba(134, 88, 64, 0.7);
	z-index: -1;
	transition: 0.5s ease-in-out;
}
a:hover:before {
	width: 100%;
}
.logout:hover {
 	color: red;
 	transition: 0.5s ease-in-out;
}
.logout:before {
	border-bottom: 5px solid red;
}
 	</style>
 </head>
 <body>
 <div class="container">
			<header class="active" id="navbar">
				<a  href="#" class="logo">Coffee<span>Shop</span></a>
					

				
				<span class="menuIcon" onclick="menuToggle();"></span>
				</header>	

		

		<h1>Looks Like There's Nothing In The Database...</h1>
		<br>
		<h2><a href="settings.php"> Click Here To Search Again</a></h2>
		<br>
		<h2><a href="signout.php" class="logout"> Click Here To Log Out</a></h2>
	</div>
 </body>
 </html>