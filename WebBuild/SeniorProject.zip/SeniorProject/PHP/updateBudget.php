<?php 	

DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();
	$user = $_SESSION['user'];

	if($con) {
		if(isset($user)) {
			$budget = mysqli_real_escape_string($con,$_POST['budget']);
			$sql = "UPDATE phpmyadmin.userlogin SET Budget=$budget WHERE Username='$user' ";
			$connect = mysqli_query($con,$sql);

			if($connect) {
				header("Location: Welcome.php");
				exit();
			}
		}
	}




 ?>