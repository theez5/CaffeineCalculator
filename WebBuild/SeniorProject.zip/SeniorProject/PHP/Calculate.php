<?php 

	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);


if(isset($_POST['submit'])) {
	echo " <div class='container'>
      <header class='active' id='navbar'>
        <a  href='#' class='logo'>Coffee<span>Shop</span></a>
        <ul>
          <li><a href='index.html'>Home</a></li>
          <li><a href='#'>Menu</a></li>
          <li><a href='Calculator.html' class='active'>Calculator</a></li>
          <li><a href='#'>About</a></li>
          <li><a href='#'>Contact</a></li>
        </ul> 
        <span class='menuIcon' onclick='menuToggle();'></span>
        </header> 
        <label class='cups'>You can find your budget below:</label>
";
    $j=0;
		if(!empty($_POST["check"])) {
			$b=0;
			session_start();
			$quan = $_COOKIE['cookie'];
			foreach ($_POST["check"] as $i) {
				$b++;
				$query = "SELECT * FROM phpmyadmin.coffee WHERE (ID = $i)";
				
				$result = mysqli_query($con,$query);
				
				if(mysqli_affected_rows($con)>=1) {
					

				while($row = mysqli_fetch_array($result))  {
			 	$ID = $row['ID'];
			 	$CoffeeType = $row['CoffeeType'];
			 	$Size = $row['Size'];
			 	$AvgPrice = $row['AvgPrice'];
			 	$Store = $row['Store'];
        $Sugar = $row['Sugar'];
        $Calories = $quan*($row['Calories']);
        $Total_Fat = $quan*($row['Total_Fat']);
        $Protein = $quan*($row['Protein']);
        $Caffeine = $quan*($row['Caffeine']);

			 	if($ID <>"")
			 		$weekly = $quan*($AvgPrice*7);
			 	$date = date("t");
			 	$monthly = $quan*($date*$AvgPrice);
			 	$yearly = $quan*(365*$AvgPrice);
			 	$daily = $quan*$AvgPrice;
			 		echo "


<div class='contain'>
    <div class='pricing-table'>
      <h3 class='heading' name='Type[$i]' value='$ID'>$CoffeeType</h3>
      <h3 class='heading'>Size: $Size</h3>
      <form method='POST' action='Calculate2.php'>
      
      <h3 class='heading'>Quantity: $quan</h3>

      
      <h1 class='service-price' style='color:Turquoise;'>
        Daily: $daily
        <sup class='dollar-sign'>$</sup>
      </h1>
      <h1 class='service-price' style='color:Gold;'>
        Weekly: $weekly
        <sup class='dollar-sign'>$</sup>
      </h1>
      <h1 class='service-price' style='color:#98ff98 ;''>
        Monthly: $monthly
        <sup class='dollar-sign'>$</sup>
      </h1>
      <h1 class='service-price' style='color:#ff007f ;'>
        Yearly: $yearly
        <sup class='dollar-sign'>$</sup>
      </h1>
      
      <ul class='features-list'>
        <li>
          Location: $Store
        </li>
      
      </ul>
    
    <a href='../index.html' class='order-button'>Start New?</a>
    <input type='submit' name='submit' class='order-button'>
</form>
   
    </div>








    <div class='pricing-table'>
      
      <h3 class='heading'><b>Nutrition Facts</b></h3><hr><br>
      <h1 class='service-price'>
        Per $quan Servings
      </h1>
      
      <ul class='features-list'>
        <li>
          <i class='fa fa-check'></i>
          Calories: $Calories
        </li>
        
          <li>
          <i class='fa fa-check'></i>
          Sugar: $Sugar mg
        </li>
        
         <li>
          <i class='fa fa-check'></i>
          Total Fat: $Total_Fat mg
        </li>
             
             
            <li>
          <i class='fa fa-check'></i>
          Protein: $Protein mg
        </li>

         <li>
          <i class='fa fa-check'></i>
          Caffeine: $Caffeine mg
        </li>
       
      </ul>
      
      <button class='order-button'>
        Order Now
      </button>
   
    </div>
    </div>";


$j++;



		} 
				
				}
			}
			
	
	}
		}
	

	
	



 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	
 	<link rel="stylesheet" type="text/css" href="../CSS/index.css">
 	<link rel="stylesheet" href="../CSS/style.css">
 	<style type="text/css">
     *{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body{
      font-family: tahoma;
    }
   label {
  font-size: 34px;
  font-weight: 700;
  color: #333;
}
  
    .contain{
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 10%;
     
      
    }
    
    .contain .pricing-table{
      display: block;
      padding: 20px;
      background: #ccc;
      overflow: hidden;
      width: 500px;
      margin: 10px;
      border-radius: 3px;
      box-shadow: 0px 8px 15px rgba(0,0,0,0.2);
      transform: scale(1);
      transition: all 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    
    .contain .pricing-table:nth-child(1){
      background-image: linear-gradient(135deg, #592d1d 10%, #c89253 100%);
    }
       .contain .pricing-table:nth-child(2){
      background-image: linear-gradient(135deg, #865840 10%, #642b09 100%);
    }
    
    
    
    .contain .pricing-table:hover{
      transform: scale(1.2);
      z-index: 100;
    }
    
    .pricing-table .icon{
      display: block;
      width: 70px;
      height: 70px;
      background: white;
      text-align: center;
      line-height: 70px;
      font-size: 2.2em;
      margin: 20px auto;
      border-radius: 50px;
      box-shadow: 0px 5px 5px rgba(0,0,0,0.2);
      
    }
    
    .pricing-table .icon span{
      transform: scale(1);
      transition: all 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    
    
    .pricing-table .type-01{
      color: #fccf31;
      
    }
    
    
    .pricing-table .type-02{
      color: #f761a1;
      
    }
    
    .pricing-table .type-03{
      color: #43cbff;
      
    }
    
    .heading{
      color: white;
      text-align: center;
      text-transform: capitalize;
      font-weight: lighter;
      padding: 10px;
      font-size: 1.2em;
    }
    
    .service-price{
      color: white;
      text-align: center;
      font-size:2em;   
      
    }
    
    .service-price .dollar-sign{
      font-size: 0.6em;
      margin-left: -10px;
      
    }
    
    .features-list{
      list-style: none;
      display: block;
      margin: 20px auto;
      width: 80%;
      
    }
    
    .features-list li{
      color: white;
      text-align: center;
      display: block;
      text-transform: capitalize;
      font-weight: lighter;
      font-size: 0.9em;
      height: 30px;
      line-height: 30px;
    }
    
    .order-button{
      border: none;
      display: block;
      width: 70%;
      height: 40px;
      margin: 10px auto;
      text-align: center;
      text-decoration: none;
      border-radius: 50px;
      box-shadow: 0px 8px 15px rgba(0,0,0,0.2);
      font-family: tahoma;
      text-transform: capitalize;
      color: rgba(0,0,0,0.5);
      background: white;
      cursor: pointer;
      
    }
    
    
    .order-button:focus{
      outline: none;
    }
   </style>
 </head>
 <body>
 	
 
 </body>
 </html>