<?php 
	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();

	$user = $_SESSION['user'];
	$Budget = $_SESSION['budget'];

	if($con) {
		if(isset($user)) {
			$sql = "SELECT * FROM phpmyadmin.Portfolio_$user";
			$connect = mysqli_query($con,$sql);
		
	} else {
		header("Location: ../index.html");
	}



while ($rows=mysqli_fetch_array($connect)) {
					$product_id = $rows['id'];
					$Calories = $rows['Calories'];
					$Fat = $rows['Fat'];
					$Caffeine = $rows['Caffeine'];
					$Protein = $rows['Protein'];
					$Sugar = $rows['Sugar'];
					$Quantity = $rows['Quantity'];



					

				
}

  
 	
 			$type = $_SESSION['type'];
			$size = $_SESSION['size'];

			

 	$query = "SELECT * FROM phpmyadmin.coffee WHERE Size = '$size' && CoffeeType like '%$type%' && AvgPrice<= $Budget && Sugar<=$Sugar && Calories<=$Calories && Total_Fat<=$Fat && Protein <=$Protein && Caffeine <= $Caffeine";
 	$queryConnect = mysqli_query($con,$query);
 	$count = mysqli_num_rows($queryConnect);
 	if($queryConnect) {
 		if($count>0) {


 			
  
				
				while ($row=mysqli_fetch_array($queryConnect)) {
					$product_idd = $row['ID'];
					$Caloriess = $row['Calories'];
					$Fat = $row['Total_Fat'];
					$Caffeine = $row['Caffeine'];
					$Protein = $row['Protein'];
					$Sugar = $row['Sugar'];
					$price = $row['AvgPrice'];
					$coffeeTy = $row['CoffeeType'];
					$daily = $Quantity*$price;
					$weekly = 7*(($Quantity) * $price);
					$Monthly = $Quantity*((date('t')*$price));
					$Yearly = 365 * ($Quantity * $price);

					$MonthIn = $Budget - $Monthly;
					$MonthOver = $Monthly - $Budget;
					$WeekIn = $Budget - $weekly;
					$WeekOver = $weekly - $Budget;
					$DailyIn = $Budget - $daily;
					$DailyOver = $Monthly - $daily;
					$YearlyIn = $Budget - $Yearly;
					$YearlyOut = $Yearly - $Budget;

					$totalIn = abs($Budget - ($daily + $weekly + $Monthly + $Yearly));
					$totalOut = abs(($daily + $weekly + $Monthly + $Yearly) - $Budget);
				
}

 	

	



 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../CSS/Welcome.css">
	<link rel="stylesheet" type="text/css" href="../CSS/Calendar.css">
	
	<style type="text/css">
		.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

	</style>
 </head>
 <body>
 <div class="container">
			<header class="active" id="navbar">
				<a  href="#" class="logo">My<span>Coffee</span></a>
					

				<ul>
					<li><a href="Welcome.php">Home</a></li>
					<li>
					
						<a href="signout.php" class="logout">Sign Out</a>
						
					</li>
					<li><a href="settings.php"><?php echo $user; ?></a></li>
					<li>
						<div class="dropdown">
						<a href="Calculator.html">  <?php
							if(($daily>$Budget)|| ($weekly>$Budget) || ($Monthly>$Budget) || ($Yearly>$Budget))  {
								echo " <font color='red'>Over Budget</font>";
							} else{
								echo " Budget: <font color='green'>$$Budget</font><br>";
							}  



					 ?>
					</a>
					<div class="dropdown-content">
						<p><?php 

							if($daily>$Budget) {
								echo "Daily: <font color='red'>$$daily</font><br>";
							} else if($daily<$Budget) {
								echo "Daily: <font color='green'>$$daily</font><br>";
							}  if($weekly>$Budget) {
								echo "Weekly: <font color='red'>$$weekly</font><br>";
							} else if($weekly<$Budget) {
								echo "Weekly: <font color='green'>$$weekly</font><br>";
							} if($Monthly>$Budget) {
								echo "Monthly: <font color='red'>$$Monthly</font><br>";
							} else if($Monthly<$Budget) {
								echo "Monthly: <font color='green'>$$Monthly</font><br>";
							} if($Yearly>$Budget) {
								echo "Yearly: <font color='red'>$$Yearly</font><br>	";
							} else if($Monthly<$Budget) {
								echo "Yearly: <font color='green'>$$Yearly</font><br>";
							} 

						 ?></p>
					</div>
				</div>
				</li>
					<li><a href="portfolio.php" class="active">My Coffee</a></li>
					
				</ul>	
				<span class="menuIcon" onclick="menuToggle();"></span>
				</header>	

<?php 
 } else {
 	header("Location: alert.php");
 } }
	$query2 = "SELECT * FROM phpmyadmin.coffee WHERE Size = '$size' && CoffeeType like '%$type%' && AvgPrice<= $Budget && Sugar<=$Sugar && Calories<=$Calories && Total_Fat<=$Fat && Protein <=$Protein && Caffeine <= $Caffeine";
 	$queryConnect2 = mysqli_query($con,$query);

 
  
				
				while ($row2=mysqli_fetch_array($queryConnect2)) {
					$product_idd = $row2['ID'];
					$Caloriess = $row2['Calories'];
					$Fat = $row2['Total_Fat'];
					$Caffeine = $row2['Caffeine'];
					$Protein = $row2['Protein'];
					$Sugar = $row2['Sugar'];
					$price = $row2['AvgPrice'];
					$coffeeTy = $row2['CoffeeType'];
					$daily = $Quantity*$price;
					$weekly = 7*(($Quantity) * $price);
					$Monthly = $Quantity*((date('t')*$price));
					$Yearly = 365 * ($Quantity * $price);

					$MonthIn = $Budget - $Monthly;
					$MonthOver = $Monthly - $Budget;
					$WeekIn = $Budget - $weekly;
					$WeekOver = $weekly - $Budget;
					$DailyIn = $Budget - $daily;
					$DailyOver = $Monthly - $daily;
					$YearlyIn = $Budget - $Yearly;
					$YearlyOut = $Yearly - $Budget;

					$totalIn = abs($Budget - ($daily + $weekly + $Monthly + $Yearly));
					$totalOut = abs(($daily + $weekly + $Monthly + $Yearly) - $Budget);

					$totalCalories = $Monthly * ($Quantity*$Caloriess);
					$totalFat = $Monthly * ($Quantity*$Fat);
					$totalCaffeine = $Monthly * ($Quantity*$Caffeine);
					$totalSugar = $Monthly * ($Quantity*$Sugar);
					$totalProtein = $Monthly * ($Quantity*$Protein);

					$WeeklytotalCalories = $weekly * ($Quantity*$Caloriess);
					$WeeklytotalFat = $weekly * ($Quantity*$Fat);
					$WeeklytotalCaffeine = $weekly * ($Quantity*$Caffeine);
					$WeeklytotalSugar = $weekly * ($Quantity*$Sugar);
					$WeeklytotalProtein = $weekly * ($Quantity*$Protein);

					$DailytotalCalories = $daily * ($Quantity*$Caloriess);
					$DailytotalFat = $daily * ($Quantity*$Fat);
					$DailytotalCaffeine = $daily * ($Quantity*$Caffeine);
					$DailytotalSugar = $daily * ($Quantity*$Sugar);
					$DailytotalProtein = $daily * ($Quantity*$Protein);

					$YearlytotalCalories = $Yearly * ($Quantity*$Caloriess);
					$YearlytotalFat = $Yearly * ($Quantity*$Fat);
					$YearlytotalCaffeine = $Yearly * ($Quantity*$Caffeine);
					$YearlytotalSugar = $Yearly * ($Quantity*$Sugar);
					$YearlytotalProtein = $Yearly * ($Quantity*$Protein);

 ?>

<h1><?php echo $coffeeTy; ?></h1>

<h1>Size: <?php echo "$size"; ?></h1>
						 <div id="container">

 

    <div class="pricetab">
      <h1> MONTHLY: </h1>
      <div class="price"> 
        <h2>$<?php echo $Monthly; ?></h2> 
      </div>
      <div class="infos">
        <h3> Budget: $<?php echo $Budget; ?> </h3><br>

        <h3><?php 
        	if($Monthly<$Budget) {
        	
        		echo "<font color='green'>In Budget: $$MonthIn </font> ";
        	} else {
        	
        		echo "<font color='red'>Over Budget: $$MonthOver </font>";
        	}

         ?>
       </h3>
       
      </div>
      <div class="pricefooter">
        <div class="button">
          <a href="#"> Total Expenses: $<?php 

          if($Monthly<$Budget) {
        		
        		echo "$totalIn ";
        	} else {
        		
        		echo "$totalOut";
        	}


          ?> </a>
        </div>
      </div>
    </div>

    <div class="pricetabmid">
      <h1> WEEKLY: </h1>
      <div class="pricemid"> 
        <h2>$<?php echo $weekly; ?></h2> 
      </div>
      <div class="infos">
       <h3> Budget: $<?php echo $Budget; ?> </h3><br>

        <h3><?php 
        	if($weekly<$Budget) {
        		
        		echo "<font color='green'>In Budget: $$WeekIn </font> ";
        	} else {
        		
        		echo "<font color='red'>Over Budget: $$WeekOver </font>";
        	}

         ?>
       </h3>
      </div>
      <div class="pricefootermid">
        <div class="buttonmid">
          <a href="#"> Total Expenses:  $<?php 

          	if($weekly<$Budget) {
        		
        		echo "$totalIn ";
        	} else {
        		
        		echo "$totalOut";
        	}




           ?></a>
        </div>
      </div>
    </div>

    <div class="pricetabmid">
      <h1> DAILY: </h1>
      <div class="pricemid"> 
        <h2>$<?php echo $daily; ?> </h2> 
      </div>
      <div class="infos">
        <h3> Budget: $<?php echo $Budget; ?> </h3><br>

        <h3><?php 
        	if($daily<$Budget) {
        		
        		echo "<font color='green'>In Budget: $$DailyIn </font> ";
        	} else {
        		
        		echo "<font color='red'>Over Budget: $$DailyOver </font>";
        	}

         ?>
       </h3>
      </div>
      <div class="pricefootermid">
        <div class="buttonmid">
          <a href="#"> Total Expenses: $<?php 

          	if($daily<$Budget) {
        		
        		echo "$totalIn ";
        	} else {
        		
        		echo "$totalOut";
        	}



           ?></a>
        </div>
      </div>
    </div>

    <div class="pricetab">
      <h1> YEARLY: </h1>
      <div class="price"> 
        <h2>$<?php echo $Yearly; ?></h2> 
      </div>
      <div class="infos">
       <h3> Budget: $<?php echo $Budget; ?> </h3><br>

        <h3><?php 
        	if($Yearly<$Budget) {
        		
        		echo "<font color='green'>In Budget: $$YearlyIn </font> ";
        	} else {
        		
        		echo "<font color='red'>Over Budget: $$YearlyOut </font>";
        	}

         ?>
       </h3>
      </div>
      <div class="pricefooter">
        <div class="button">
          <a href="#"> Total Expenses: $<?php 

          if($Yearly<$Budget) {
        		
        		echo "$totalIn ";
        	} else {
        		
        		echo "$totalOut";
        	}


           ?></a>
        </div>
      </div>
    </div>
    
  </div>


   <div id="container2">

 

    <div class="pricetab2">
      <h1 class="h1"> Nutrition Facts: </h1>
      <div class="price2"> 
        <h2 class="h2">Monthly</h2> 
      </div>
      <div class="infos"><hr>
        <h3 class="h3"> Total Calories: <?php echo $totalCalories; ?>  </h3>
        <h3 class="h3"> Total Fat: <?php echo $totalFat; ?> Grams</h3>
        <h3 class="h3"> Total Caffeine: <?php 	echo $totalCaffeine; ?> MG</h3>
        <h3 class="h3"> Total Protein: <?php 	echo $totalProtein; ?> Grams</h3>
        <h3 class="h3"> Total Sugar: <?php 	echo $totalSugar; ?> Grams</h3>

       
       
      </div>
      <div class="pricefooter">
        <div class="button">
          <a href="#"></a>
        </div>
      </div>
    </div>

    <div class="pricetabmid2">
      <h1 class="h1mid"> Nutrition Facts: </h1>
      <div class="pricemid2"> 
        <h2>Weekly</h2> 
      </div>
      <div class="infos"><hr>
      	<h3> Total Calories: <?php echo $WeeklytotalCalories; ?>  </h3>
        <h3> Total Fat: <?php echo $WeeklytotalFat; ?> Grams</h3>
        <h3> Total Caffeine: <?php 	echo $WeeklytotalCaffeine; ?> MG</h3>
        <h3> Total Protein: <?php 	echo $WeeklytotalProtein; ?> Grams</h3>
        <h3> Total Sugar: <?php 	echo $WeeklytotalSugar; ?> Grams</h3>
      </div>
      <div class="pricefootermid">
        <div class="buttonmid">
          <a href="#"> </a>
        </div>
      </div>
    </div>

    <div class="pricetabmid2">
      <h1 class="h1mid"> Nutrition Facts: </h1>
      <div class="pricemid2"> 
        <h2>Daily </h2> 
      </div>
      <div class="infos"><hr>
      	<h3> Total Calories: <?php echo $DailytotalCalories; ?>  </h3>
        <h3> Total Fat: <?php echo $DailytotalFat; ?> Grams</h3>
        <h3> Total Caffeine: <?php 	echo $DailytotalCaffeine; ?> MG</h3>
        <h3> Total Protein: <?php 	echo $DailytotalProtein; ?> Grams</h3>
        <h3> Total Sugar: <?php 	echo $DailytotalSugar; ?> Grams</h3>
       
      </div>
      <div class="pricefootermid">
        <div class="buttonmid">
          <a href="#"></a>
        </div>
      </div>
    </div>

    <div class="pricetab2">
      <h1 class="h1"> Nutrition Facts: </h1>
      <div class="price2"> 
        <h2 class="h2">Yearly</h2> 
      </div>
      <div class="infos"><hr>
        <h3 class="h3"> Total Calories: <?php echo $YearlytotalCalories; ?>  </h3>
        <h3 class="h3"> Total Fat: <?php echo $YearlytotalFat; ?> Grams</h3>
        <h3 class="h3"> Total Caffeine: <?php 	echo $YearlytotalCaffeine; ?> MG</h3>
        <h3 class="h3"> Total Protein: <?php 	echo $YearlytotalProtein; ?> Grams</h3>
        <h3 class="h3"> Total Sugar: <?php 	echo $YearlytotalSugar; ?> Grams</h3>
       
      </div>
      <div class="pricefooter">
        <div class="button">
          <a href="#"> 


           </a>
        </div>
      </div>
    </div>
    
  </div>
<hr>


 </body>
 </html>

 <?php   }} ?>