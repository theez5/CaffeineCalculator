<?php $ct=0;
	DEFINE ('DB_USER', 'root');                                        
	DEFINE ('DB_PSWD', '');
	DEFINE ('DB_HOST', '127.0.0.1');
	DEFINE ('DB_NAME', 'phpmyadmin');
	$con = mysqli_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

	session_start();
	$user = $_SESSION['user'];

	if(isset($user)) {

	for($i=0;$i<count($_POST['product_id']);$i++) {

		$product_id[$i]=$_POST["product_id"][$i];
		$Calories[$i]=$_POST["Calories"][$i];
		$Fat[$i]=$_POST["Fat"][$i];
		$Caffeine[$i]=$_POST["Caffeine"][$i];
		$Protein[$i]=$_POST["Protein"][$i];
		$Sugar[$i]=$_POST["Sugar"][$i];
		$Quantity[$i]=$_POST["Quantity"][$i];
		$types = $_POST["Types"];
		$sizes = $_POST["Sizes"];
			
			$_SESSION['type'] = $types;
			$_SESSION['size'] = $sizes;
			
			}

		
	
	for($i=0;$i<count($_POST['product_id']);$i++) {
		$query="UPDATE phpmyadmin.portfolio_$user Set Calories=$Calories[$i],Fat=$Fat[$i], Caffeine=$Caffeine[$i],
		Protein=$Protein[$i],Sugar=$Sugar[$i], Quantity=$Quantity[$i] WHERE ( id=$product_id[$i] )";
		$result = mysqli_query($con,$query);

		if($result) {
			if(mysqli_affected_rows($con)>=1) {
				echo "<br> Success, Updated Product: <b>$Quantity[$i]</b><br> \n";
				echo $query;
				$ct++;
				header("Location: portfolio.php");
				exit();
				
			}
		}	else {
			header("Location: portfolio.php");
			echo "string";
			
		}
}
}
header("Location: portfolio.php");
 ?>